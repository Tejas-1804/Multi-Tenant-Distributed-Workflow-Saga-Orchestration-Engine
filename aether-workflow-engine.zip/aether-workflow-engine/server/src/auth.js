import jwt from "jsonwebtoken";
export function requireAuth(req,res,next){
  const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");
  try { if(!token) throw new Error("Missing token"); req.auth=jwt.verify(token,process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({error:"Authentication required"}); }
}
export function tenantScope(req,res,next){ req.tenantId=req.auth.tenantId; next(); }
