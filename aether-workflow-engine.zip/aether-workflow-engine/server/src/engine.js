import {Workflow,Execution} from "./models.js";
import {validateGraph} from "./dag.js";
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function runAction(node,context){
 const action=node.data?.action||"echo";
 if(action==="delay"){await wait(Math.min(Number(node.data?.ms)||500,5000));return {delayed:true};}
 if(action==="fail") throw new Error(node.data?.message||"Requested test failure");
 if(action==="set") return {[node.data?.key||"value"]:node.data?.value??"done"};
 return {message:node.data?.message||`Completed ${node.data?.label||node.id}`};
}
export async function executeWorkflow(executionId,tenantId){
 const execution=await Execution.findOne({_id:executionId,tenantId});
 if(!execution) throw new Error("Execution not found");
 const workflow=await Workflow.findOne({_id:execution.workflowId,tenantId});
 if(!workflow) throw new Error("Workflow not found");
 const check=validateGraph(workflow.nodes,workflow.edges);
 if(!check.valid) throw new Error(check.errors.join(" "));
 execution.status="running";await execution.save();
 const nodeById=new Map(workflow.nodes.map(n=>[n.id,n]));
 const completed=[],results={}; const steps=[];
 try{
  for(const id of check.order){
   const node=nodeById.get(id);
   const incoming=workflow.edges.filter(e=>e.target===id);
   if(incoming.some(e=>e.condition && results[e.source]?.[e.condition.key]!==e.condition.equals)) {steps.push({nodeId:id,status:"skipped"});continue;}
   const startedAt=new Date();
   try{
    const output=await runAction(node,results);
    results[id]=output;completed.push(node);
    steps.push({nodeId:id,label:node.data.label,status:"completed",output,startedAt,finishedAt:new Date()});
   }catch(err){steps.push({nodeId:id,label:node.data.label,status:"failed",error:err.message,startedAt,finishedAt:new Date()});throw err;}
  }
  execution.status="completed";execution.results=results;execution.steps=steps;await execution.save();return execution;
 }catch(err){
  execution.status="compensating";execution.error=err.message;execution.steps=steps;await execution.save();
  const compensation=[];
  for(const node of completed.reverse()){
   if(node.data?.compensateAction){
    try{const output=await runAction({...node,data:{...node.data,action:node.data.compensateAction,label:`Compensate ${node.data.label}`}},results);compensation.push({nodeId:node.id,status:"compensated",output});}
    catch(e){compensation.push({nodeId:node.id,status:"compensation_failed",error:e.message});}
   }
  }
  execution.status=compensation.some(x=>x.status==="compensation_failed")?"failed":"compensated";
  execution.steps=[...steps,...compensation];await execution.save();throw err;
 }
}
