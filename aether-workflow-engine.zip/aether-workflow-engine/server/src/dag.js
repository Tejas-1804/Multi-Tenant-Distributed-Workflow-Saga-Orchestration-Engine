export function validateGraph(nodes=[],edges=[]){
 const errors=[],ids=new Set(nodes.map(n=>n.id));
 if(!nodes.length) errors.push("Add at least one node.");
 if(ids.size!==nodes.length) errors.push("Node IDs must be unique.");
 const indegree=new Map(nodes.map(n=>[n.id,0])),out=new Map(nodes.map(n=>[n.id,[]]));
 for(const e of edges){
  if(!ids.has(e.source)||!ids.has(e.target)){errors.push(`Edge ${e.id||""} references a missing node.`);continue;}
  if(e.source===e.target){errors.push("A node cannot connect to itself.");continue;}
  out.get(e.source).push(e.target); indegree.set(e.target,indegree.get(e.target)+1);
 }
 const q=[...indegree].filter(([,d])=>d===0).map(([id])=>id),order=[];
 while(q.length){const id=q.shift();order.push(id);for(const next of out.get(id)){indegree.set(next,indegree.get(next)-1);if(indegree.get(next)===0)q.push(next);}}
 if(order.length!==nodes.length) errors.push("Cycle detected. Workflow graphs must be acyclic.");
 for(const n of nodes) if(!n.data?.label) errors.push(`Node ${n.id} needs a label.`);
 return {valid:errors.length===0,errors,order};
}
