import "dotenv/config";import {Worker} from "bullmq";import {connection} from "./queue.js";import {connectDB} from "./db.js";import {executeWorkflow} from "./engine.js";
await connectDB();
new Worker("workflow-runs",async job=>executeWorkflow(job.data.executionId,job.data.tenantId),{connection,concurrency:5}).on("completed",job=>console.log("Completed",job.id)).on("failed",(job,err)=>console.error("Job failed",job?.id,err.message));
console.log("Workflow worker started");
