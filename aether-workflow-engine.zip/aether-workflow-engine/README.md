# Aether Workflow Engine — MVP

A runnable multi-tenant workflow orchestration starter built with React, Express, MongoDB, React Flow, and BullMQ.

## Prerequisites
Node.js 20+, MongoDB, Redis (BullMQ worker queue), npm.

## Run
1. Copy `server/.env.example` to `server/.env` and set `MONGO_URI`, `JWT_SECRET`, and `API_KEY_PEPPER`.
2. Start MongoDB and Redis.
3. From this folder run:
   ```bash
   npm install
   npm run install:all
   npm run dev
   ```
4. Open the Vite URL shown in the terminal. Register an organization and start building.

## Included
- Tenant-scoped records and authenticated JWT sessions.
- API key creation (only the hash is persisted; secret shown once).
- React Flow canvas, DAG cycle/dependency validation, conditional edges.
- Persisted workflow definitions and execution logs.
- BullMQ worker, exponential retry settings, and basic Saga compensation.
- MongoDB Change Stream watcher (requires replica set; set `ENABLE_CHANGE_STREAMS=true`).
- Health endpoint and rate limiting.

## Important
This is a development MVP, not a production-hardened workflow platform. Before production, add tenant-aware authorization tests, secret rotation, idempotency keys, durable outbox/event processing, audit retention, queue monitoring, TLS, and deployment-specific secrets. External actions must be idempotent and compensation handlers must be safe to repeat.
