# Deployment Guide

## Local development (Windows / VS Code)

1. Install Node.js 22 or newer.
2. Open this project folder in VS Code.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Replace `JWT_SECRET` with a private random value of at least 32 characters.
6. Run `npm run dev` and open `http://localhost:3000`.

## Production considerations

The current implementation stores data in `.data/db.json` and runs workflow execution in the application process. It is intended for local development, demos, and single-instance deployments. Before horizontally scaling or using this for production workloads, replace the JSON store with a transactional database adapter, move execution to a durable queue/worker service, configure a strong secret manager, and set an explicit CORS allowlist.

The `MONGODB_URI` and `REDIS_URL` environment variables are not currently consumed by the application. No MongoDB or Redis integration is included in this version.
