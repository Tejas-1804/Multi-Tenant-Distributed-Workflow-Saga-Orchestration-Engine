# Data Storage & Tenant Isolation

## Current storage implementation

The application uses a JSON file store implemented in `server/db.ts`, persisted at `.data/db.json`. The store includes tenants, users, workflows, executions, node execution logs, API keys, audit logs, dead-letter jobs, and workers. It writes the complete store to disk after mutations.

This implementation is intentionally lightweight for local development and demos. It is not a substitute for a transactional database in multi-process or horizontally scaled production deployments. MongoDB/Mongoose models and a MongoDB adapter are not included in this ZIP.

## Tenant isolation

- Authenticated users receive a tenant ID from their verified server-side user record.
- Tenant-owned workflow and execution lookups are scoped by tenant ID.
- A `SUPER_ADMIN` may inspect another tenant using `x-target-tenant-id`.
- Never trust a tenant ID supplied in a request body as authorization.

## Stored collections

1. Tenant
2. User (password hashes only)
3. Workflow
4. WorkflowExecution and node execution logs
5. APIKey (hash only)
6. DeadLetterJob
7. AuditLog
8. WorkerInfo
