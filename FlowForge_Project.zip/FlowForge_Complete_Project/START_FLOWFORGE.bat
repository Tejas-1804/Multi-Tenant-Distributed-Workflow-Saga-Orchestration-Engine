@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   FlowForge - Local Development Launcher
echo ==========================================

if not exist ".env" (
  echo [SETUP] Creating .env from .env.example
  copy ".env.example" ".env" >nul
  echo [ACTION REQUIRED] Open .env and replace JWT_SECRET with a private random value of at least 32 characters.
  echo Then run this file again.
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo [SETUP] Installing dependencies...
  call npm install
  if errorlevel 1 goto :error
)

echo [START] Launching FlowForge at http://localhost:3000
call npm run dev
exit /b %errorlevel%

:error
echo [ERROR] Setup failed. Check the messages above and try again.
pause
exit /b 1
