import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar, NavTab } from './components/Sidebar.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { WorkflowBuilderPage } from './pages/WorkflowBuilderPage.tsx';
import { WorkflowsListPage } from './pages/WorkflowsListPage.tsx';
import { ExecutionsListPage } from './pages/ExecutionsListPage.tsx';
import { ExecutionDetailPage } from './pages/ExecutionDetailPage.tsx';
import { TemplatesPage } from './pages/TemplatesPage.tsx';
import { TenantsPage } from './pages/TenantsPage.tsx';
import { WorkersPage } from './pages/WorkersPage.tsx';
import { MonitoringPage } from './pages/MonitoringPage.tsx';
import { AlertsPage } from './pages/AlertsPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { useWebSocket } from './hooks/useWebSocket.ts';
import api from './services/api.ts';

function AppContent() {
  const { user, tenant, isLoading } = useAuth();
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [activeWorkflowId, setActiveWorkflowId] = useState<string | null>(null);
  const [activeExecutionId, setActiveExecutionId] = useState<string | null>(null);
  const [alertCount, setAlertCount] = useState<number>(3);

  // Connect WebSocket to active tenant
  const { isConnected, lastEvent } = useWebSocket(tenant?.id);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center font-sans text-xs text-slate-500">
        <div className="flex items-center gap-2.5 bg-white px-5 py-3 rounded-xl border border-slate-200 shadow-sm">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-ping" />
          <span className="font-semibold text-slate-700">Connecting to FlowForge Engine...</span>
        </div>
      </div>
    );
  }

  // If user is not authenticated and not auto-logged in, show Auth
  if (!user) {
    return <AuthPage initialMode="login" />;
  }

  const handleOpenWorkflowBuilder = (workflowId?: string) => {
    setActiveWorkflowId(workflowId || null);
    setCurrentTab('builder');
  };

  const handleOpenExecutionDetail = (executionId: string) => {
    setActiveExecutionId(executionId);
    setCurrentTab('execution-detail');
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex font-sans selection:bg-blue-100 selection:text-blue-700">
      {/* Left Deep Navy Navigation Sidebar matching Screenshots */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={tab => {
          if (tab === 'workflows') setActiveWorkflowId(null);
          if (tab === 'executions') {
            // Default to execution detail matching Screenshot 2 & 3 or allow toggle
            setActiveExecutionId(null);
            setCurrentTab('executions');
            return;
          }
          setCurrentTab(tab);
        }}
        alertCount={alertCount}
      />

      {/* Main Column */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Top Header matching Screenshots */}
        <Navbar
          onNavigateTab={tab => setCurrentTab(tab)}
        />

        {/* Dynamic Page Content */}
        <main className="flex-1 overflow-y-auto bg-[#f8fafc]">
          {currentTab === 'dashboard' && (
            <DashboardPage
              onOpenWorkflowBuilder={handleOpenWorkflowBuilder}
              onOpenExecutionDetail={handleOpenExecutionDetail}
              onNavigateTab={tab => {
                if (tab === 'executions') {
                  setActiveExecutionId(null);
                  setCurrentTab('executions');
                } else {
                  setCurrentTab(tab);
                }
              }}
            />
          )}

          {currentTab === 'workflows' && (
            <WorkflowsListPage
              onOpenBuilder={handleOpenWorkflowBuilder}
              onOpenExecution={handleOpenExecutionDetail}
            />
          )}

          {currentTab === 'builder' && (
            <WorkflowBuilderPage
              workflowId={activeWorkflowId}
              onBack={() => setCurrentTab('workflows')}
              onOpenExecutionDetail={handleOpenExecutionDetail}
            />
          )}

          {currentTab === 'executions' && (
            <ExecutionsListPage onOpenExecution={handleOpenExecutionDetail} />
          )}

          {currentTab === 'execution-detail' && (
            <ExecutionDetailPage
              executionId={activeExecutionId || ''}
              onBack={() => setCurrentTab('executions')}
              onOpenWorkflow={handleOpenWorkflowBuilder}
            />
          )}

          {currentTab === 'templates' && (
            <TemplatesPage
              onInstantiateTemplate={wfId => handleOpenWorkflowBuilder(wfId)}
            />
          )}

          {currentTab === 'tenants' && <TenantsPage />}

          {currentTab === 'workers' && <WorkersPage />}

          {currentTab === 'monitoring' && <MonitoringPage />}

          {currentTab === 'alerts' && <AlertsPage />}

          {currentTab === 'settings' && <SettingsPage />}

          {currentTab === 'auth' && <AuthPage initialMode="register" />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
