import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Keep the existing light dashboard appearance; remove this class to use the dark token set.
document.documentElement.classList.add('light');

createRoot(document.getElementById('root')!).render(<App />);
