import { db } from './db.ts';
import { hashPassword, hashApiKey } from './auth.ts';

export async function seedDatabase() {
  const store = db.getStore();

  console.log('🌱 Synchronizing FlowForge multi-tenant database & Tenant Admins...');

  // 1. Ensure Tenants matching Screenshots
  let acmeTenant = db.tenants.findOne({ slug: 'acme-corp' }) || db.tenants.findOne({ slug: 'acme-logistics' });
  if (!acmeTenant) {
    acmeTenant = db.tenants.create({
      name: 'Acme Corp',
      slug: 'acme-corp',
      domain: 'acme.flowforge.com',
      plan: 'ENTERPRISE',
      rateLimitPerMinute: 2000,
      status: 'ACTIVE',
    });
  } else {
    db.tenants.update(acmeTenant.id, {
      name: 'Acme Corp',
      slug: 'acme-corp',
      domain: 'acme.flowforge.com',
      plan: 'ENTERPRISE',
      status: 'ACTIVE',
    });
  }

  let techNovaTenant = db.tenants.findOne({ slug: 'technova' });
  if (!techNovaTenant) {
    techNovaTenant = db.tenants.create({
      name: 'TechNova',
      slug: 'technova',
      domain: 'technova.flowforge.com',
      plan: 'PRO',
      rateLimitPerMinute: 1500,
      status: 'ACTIVE',
    });
  }

  let globalSystemsTenant = db.tenants.findOne({ slug: 'global-systems' });
  if (!globalSystemsTenant) {
    globalSystemsTenant = db.tenants.create({
      name: 'Global Systems',
      slug: 'global-systems',
      domain: 'global.flowforge.com',
      plan: 'ENTERPRISE',
      rateLimitPerMinute: 5000,
      status: 'ACTIVE',
    });
  }

  let quantumTenant = db.tenants.findOne({ slug: 'quantum-dynamics' });
  if (!quantumTenant) {
    quantumTenant = db.tenants.create({
      name: 'Quantum Dynamics',
      slug: 'quantum-dynamics',
      domain: 'quantum.flowforge.com',
      plan: 'PRO',
      rateLimitPerMinute: 1000,
      status: 'ACTIVE',
    });
  }

  let heliosTenant = db.tenants.findOne({ slug: 'helios-cloud' });
  if (!heliosTenant) {
    heliosTenant = db.tenants.create({
      name: 'Helios Cloud',
      slug: 'helios-cloud',
      domain: 'helios.flowforge.com',
      plan: 'ENTERPRISE',
      rateLimitPerMinute: 5000,
      status: 'ACTIVE',
    });
  }

  let cyberTenant = db.tenants.findOne({ slug: 'cyberdyne' });
  if (!cyberTenant) {
    cyberTenant = db.tenants.create({
      name: 'Cyberdyne',
      slug: 'cyberdyne',
      domain: 'cyberdyne.flowforge.com',
      plan: 'ENTERPRISE',
      rateLimitPerMinute: 5000,
      status: 'ACTIVE',
    });
  }

  // 2. Ensure Password Hashes for Tenant Admins: Tejas, Amaan, Priyanka, Rinkle Sharma
  const tejasPasswordHash = await hashPassword('Tejas123!');
  const amaanPasswordHash = await hashPassword('Amaan123!');
  const priyankaPasswordHash = await hashPassword('Priyanka123!');
  const rinklePasswordHash = await hashPassword('Rinkle123!');
  const superPasswordHash = await hashPassword('Admin123!');

  // Master System Admin
  let superAdmin = db.users.findByEmail('superadmin@orchestration.engine');
  if (!superAdmin) {
    superAdmin = db.users.create({
      tenantId: acmeTenant.id,
      name: 'Master System Administrator',
      email: 'superadmin@orchestration.engine',
      role: 'SUPER_ADMIN',
      status: 'ACTIVE',
      passwordHash: superPasswordHash,
    });
  }

  // 1. Tejas (Tenant Admin for Acme Corp)
  let tejasAdmin = db.users.findByEmail('tejas@acme.com');
  if (!tejasAdmin) {
    tejasAdmin = db.users.create({
      tenantId: acmeTenant.id,
      name: 'Tejas (Tenant Admin)',
      email: 'tejas@acme.com',
      role: 'TENANT_ADMIN',
      status: 'ACTIVE',
      passwordHash: tejasPasswordHash,
    });
  } else {
    db.users.update(tejasAdmin.id, { tenantId: acmeTenant.id, name: 'Tejas (Tenant Admin)', passwordHash: tejasPasswordHash });
  }

  let acmeAlias = db.users.findByEmail('admin@acme.com');
  if (acmeAlias) {
    db.users.update(acmeAlias.id, { tenantId: acmeTenant.id, name: 'Tejas', passwordHash: tejasPasswordHash });
  } else {
    db.users.create({
      tenantId: acmeTenant.id,
      name: 'Tejas',
      email: 'admin@acme.com',
      role: 'TENANT_ADMIN',
      status: 'ACTIVE',
      passwordHash: tejasPasswordHash,
    });
  }

  // 2. Amaan (Tenant Admin for Cyberdyne / TechNova)
  let amaanAdmin = db.users.findByEmail('amaan@cyberdyne.com');
  if (!amaanAdmin) {
    amaanAdmin = db.users.create({
      tenantId: cyberTenant.id,
      name: 'Amaan (Tenant Admin)',
      email: 'amaan@cyberdyne.com',
      role: 'TENANT_ADMIN',
      status: 'ACTIVE',
      passwordHash: amaanPasswordHash,
    });
  } else {
    db.users.update(amaanAdmin.id, { name: 'Amaan (Tenant Admin)', passwordHash: amaanPasswordHash });
  }

  // 3. Priyanka (Tenant Admin for Quantum Dynamics / Global Systems)
  let priyankaAdmin = db.users.findByEmail('priyanka@quantum.io');
  if (!priyankaAdmin) {
    priyankaAdmin = db.users.create({
      tenantId: quantumTenant.id,
      name: 'Priyanka (Tenant Admin)',
      email: 'priyanka@quantum.io',
      role: 'TENANT_ADMIN',
      status: 'ACTIVE',
      passwordHash: priyankaPasswordHash,
    });
  } else {
    db.users.update(priyankaAdmin.id, { name: 'Priyanka (Tenant Admin)', passwordHash: priyankaPasswordHash });
  }

  // 4. Rinkle Sharma (Tenant Admin for Helios Cloud)
  let rinkleAdmin = db.users.findByEmail('rinkle@helios.net');
  if (!rinkleAdmin) {
    rinkleAdmin = db.users.create({
      tenantId: heliosTenant.id,
      name: 'Rinkle Sharma (Tenant Admin)',
      email: 'rinkle@helios.net',
      role: 'TENANT_ADMIN',
      status: 'ACTIVE',
      passwordHash: rinklePasswordHash,
    });
  } else {
    db.users.update(rinkleAdmin.id, { name: 'Rinkle Sharma (Tenant Admin)', passwordHash: rinklePasswordHash });
  }

  // 3. API Keys
  const demoRawKey = 'wk_live_acme_prod_99f38e4a77194602';
  if (store.apiKeys.length === 0) {
    db.apiKeys.create({
      tenantId: acmeTenant.id,
      name: 'Production Ingestion Gateway Key',
      keyPrefix: 'wk_live_acme...',
      keyHash: hashApiKey(demoRawKey),
    });
  }

  // 4. Seed 5 Primary Workflows for Acme Corp if missing
  let orderWf = db.workflows.findOne({ tenantId: acmeTenant.id, name: 'Order Processing' });
  if (!orderWf) {
    orderWf = db.workflows.create({
      tenantId: acmeTenant.id,
      name: 'Order Processing',
      description: 'Distributed order orchestration pipeline executing validation, warehouse inventory check, payment capture, and notification fallback.',
      status: 'ACTIVE',
      createdBy: tejasAdmin.email,
      nodes: [
        {
          id: 'node-trigger',
          type: 'START',
          position: { x: 280, y: 50 },
          data: {
            label: 'Trigger',
            sublabel: 'New Order',
            duration: '234ms',
            status: 'SUCCESS',
            description: 'Customer checkout webhook event received',
          },
        },
        {
          id: 'node-validate',
          type: 'TRANSFORM',
          position: { x: 280, y: 160 },
          data: {
            label: 'Validate Order',
            duration: '512ms',
            status: 'SUCCESS',
            description: 'Validate cart line items, pricing, and fraud risk token',
          },
        },
        {
          id: 'node-inventory',
          type: 'HTTP_REQUEST',
          position: { x: 280, y: 280 },
          data: {
            label: 'Check Inventory',
            duration: '1.2s',
            status: 'RUNNING',
            description: 'Query stock levels from inventory services.',
            serviceType: 'Inventory Services / Database Query',
            inputData: {
              productId: 'PRD-1024',
              quantity: 25,
              warehouse: 'WH-01',
            },
            outputData: null,
          },
        },
        {
          id: 'node-payment',
          type: 'HTTP_REQUEST',
          position: { x: 120, y: 440 },
          data: {
            label: 'Process Payment',
            status: 'PENDING',
            description: 'Capture pre-authorized credit card transaction',
          },
        },
        {
          id: 'node-update-inv',
          type: 'HTTP_REQUEST',
          position: { x: 120, y: 560 },
          data: {
            label: 'Update Inventory',
            status: 'PENDING',
            description: 'Decrement warehouse SKU quantity and lock safety stock',
          },
        },
        {
          id: 'node-notify',
          type: 'LOG',
          position: { x: 440, y: 440 },
          data: {
            label: 'Send Notification',
            status: 'PENDING',
            description: 'Notify operations team or send out-of-stock customer alert',
          },
        },
      ],
      edges: [
        { id: 'e1', source: 'node-trigger', target: 'node-validate' },
        { id: 'e2', source: 'node-validate', target: 'node-inventory' },
        { id: 'e3', source: 'node-inventory', target: 'node-payment', sourceHandle: 'true', label: 'In Stock' },
        { id: 'e4', source: 'node-inventory', target: 'node-notify', sourceHandle: 'false', label: 'Out of Stock' },
        { id: 'e5', source: 'node-payment', target: 'node-update-inv' },
      ],
    });
  }

  // Ensure remaining 4 workflows
  const otherWorkflows = [
    { name: 'Payment Processing', desc: 'Recurring subscription billing and settlement with Stripe' },
    { name: 'User Registration', desc: 'User signup verification, JWT token issuance, and CRM sync' },
    { name: 'Email Notification', desc: 'Transactional notifications, SMS alerts, and audit logging' },
    { name: 'Inventory Update', desc: 'Multi-warehouse stock replenishment and catalog reconciliation' },
  ];

  for (const item of otherWorkflows) {
    if (!db.workflows.findOne({ tenantId: acmeTenant.id, name: item.name })) {
      db.workflows.create({
        tenantId: acmeTenant.id,
        name: item.name,
        description: item.desc,
        status: 'ACTIVE',
        createdBy: tejasAdmin.email,
        nodes: [
          { id: 'n1', type: 'START', position: { x: 200, y: 50 }, data: { label: 'Event Trigger' } },
          { id: 'n2', type: 'HTTP_REQUEST', position: { x: 200, y: 160 }, data: { label: 'Execute Task' } },
          { id: 'n3', type: 'END', position: { x: 200, y: 270 }, data: { label: 'Completed' } },
        ],
        edges: [
          { id: 'e1', source: 'n1', target: 'n2' },
          { id: 'e2', source: 'n2', target: 'n3' },
        ],
      });
    }
  }

  // 5. Seed Executions EX-1001 through EX-1005 for Acme Corp matching Screenshot 1 & 2
  const existingExec1001 = store.executions.find(e => e.id === 'EX-1001');
  if (!existingExec1001) {
    store.executions.unshift({
      id: 'EX-1001',
      workflowId: orderWf.id,
      workflowName: 'Order Processing',
      tenantId: acmeTenant.id,
      status: 'SUCCESS',
      startedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
      completedAt: new Date(Date.now() - 1000 * 60 * 30 + 2400).toISOString(),
      contextData: { productId: 'PRD-1024', quantity: 25, warehouse: 'WH-01' },
      nodeExecutions: {},
      compensationsExecuted: [],
      trigger: 'WEBHOOK',
      triggeredBy: 'api_gateway',
      duration: '2.4s',
    });
  }

  const existingExec1002 = store.executions.find(e => e.id === 'EX-1002');
  if (!existingExec1002) {
    store.executions.unshift({
      id: 'EX-1002',
      workflowId: orderWf.id,
      workflowName: 'Order Processing',
      tenantId: acmeTenant.id,
      status: 'RUNNING',
      startedAt: new Date(Date.now() - 1200).toISOString(),
      currentNodeId: 'node-inventory',
      contextData: { productId: 'PRD-1024', quantity: 25, warehouse: 'WH-01' },
      nodeExecutions: {},
      compensationsExecuted: [],
      trigger: 'MANUAL',
      triggeredBy: tejasAdmin.email,
      duration: '1.2s (in progress)',
    });
  }

  const existingExec1003 = store.executions.find(e => e.id === 'EX-1003');
  if (!existingExec1003) {
    store.executions.unshift({
      id: 'EX-1003',
      workflowId: orderWf.id,
      workflowName: 'User Registration',
      tenantId: acmeTenant.id,
      status: 'FAILED',
      startedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
      completedAt: new Date(Date.now() - 1000 * 60 * 180 + 3200).toISOString(),
      error: 'KYC Verification Service returned 502 Bad Gateway',
      contextData: { userId: 'USR-891', email: 'test@customer.com' },
      nodeExecutions: {},
      compensationsExecuted: [],
      trigger: 'API',
      triggeredBy: 'onboarding_gateway',
      duration: '3.2s',
    });
  }

  const existingExec1004 = store.executions.find(e => e.id === 'EX-1004');
  if (!existingExec1004) {
    store.executions.unshift({
      id: 'EX-1004',
      workflowId: orderWf.id,
      workflowName: 'Email Notification',
      tenantId: acmeTenant.id,
      status: 'SUCCESS',
      startedAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
      completedAt: new Date(Date.now() - 1000 * 60 * 240 + 1500).toISOString(),
      contextData: { recipient: 'buyer@example.com', template: 'order_shipped' },
      nodeExecutions: {},
      compensationsExecuted: [],
      trigger: 'EVENT',
      triggeredBy: 'notification_svc',
      duration: '1.5s',
    });
  }

  const existingExec1005 = store.executions.find(e => e.id === 'EX-1005');
  if (!existingExec1005) {
    store.executions.unshift({
      id: 'EX-1005',
      workflowId: orderWf.id,
      workflowName: 'Inventory Update',
      tenantId: acmeTenant.id,
      status: 'SUCCESS',
      startedAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(),
      completedAt: new Date(Date.now() - 1000 * 60 * 300 + 2100).toISOString(),
      contextData: { sku: 'SKU-QUANTUM-X', delta: -25 },
      nodeExecutions: {},
      compensationsExecuted: [],
      trigger: 'CRON',
      triggeredBy: 'system_scheduler',
      duration: '2.1s',
    });
  }

  // Persist store update
  db.save();

  console.log('✅ FlowForge seeded successfully with Acme Corp, TechNova, Global Systems, Quantum Dynamics, Helios Cloud, and Cyberdyne.');
  console.log('✅ Tenant Admins configured: Tejas, Amaan, Priyanka, and Rinkle Sharma.');
}
