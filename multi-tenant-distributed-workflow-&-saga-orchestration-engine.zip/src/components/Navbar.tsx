import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Bell,
  ChevronDown,
  Building2,
  Check,
  User,
  LogOut,
  UserPlus,
  ShieldCheck,
} from 'lucide-react';
import { useAuth, DEMO_PERSONAS } from '../context/AuthContext.tsx';
import api from '../services/api.ts';
import { Tenant } from '../types/index.ts';

interface NavbarProps {
  onSearch?: (term: string) => void;
  onNavigateTab?: (tab: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onSearch, onNavigateTab }) => {
  const { user, tenant, setTargetTenant, switchPersona, logout } = useAuth();
  const [tenantsList, setTenantsList] = useState<Tenant[]>([]);
  const [showTenantMenu, setShowTenantMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const tenantMenuRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notifMenuRef = useRef<HTMLDivElement>(null);

  // Fetch tenants for selector
  useEffect(() => {
    const fetchTenants = async () => {
      try {
        const res = await api.get('/tenants');
        setTenantsList(res.data);
      } catch (err) {
        // Fallback demo tenants
        setTenantsList([
          { id: 't-1', name: 'Acme Corp', slug: 'acme-corp', domain: 'acme.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 2000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          { id: 't-2', name: 'TechNova', slug: 'technova', domain: 'technova.flowforge.com', plan: 'PRO', rateLimitPerMinute: 1500, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          { id: 't-3', name: 'Global Systems', slug: 'global-systems', domain: 'global.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 5000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          { id: 't-4', name: 'Quantum Dynamics', slug: 'quantum-dynamics', domain: 'quantum.flowforge.com', plan: 'PRO', rateLimitPerMinute: 1000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          { id: 't-5', name: 'Helios Cloud', slug: 'helios-cloud', domain: 'helios.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 5000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          { id: 't-6', name: 'Cyberdyne', slug: 'cyberdyne', domain: 'cyberdyne.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 5000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
        ]);
      }
    };
    fetchTenants();
  }, []);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (tenantMenuRef.current && !tenantMenuRef.current.contains(e.target as Node)) {
        setShowTenantMenu(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
      if (notifMenuRef.current && !notifMenuRef.current.contains(e.target as Node)) {
        setShowNotificationMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value;
    setSearchQuery(term);
    onSearch?.(term);
  };

  const currentTenantName = tenant?.name || 'Acme Corp';

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between z-30 sticky top-0">
      {/* Left side spacer / mobile toggle placeholder */}
      <div className="flex items-center gap-2">
        <div className="hidden lg:block text-xs text-slate-400 font-medium">
          Workflow Orchestration Platform
        </div>
      </div>

      {/* Right controls matching Screenshots 1-4 */}
      <div className="flex items-center gap-4">
        {/* Current Tenant Selector */}
        <div className="relative" ref={tenantMenuRef}>
          <div className="flex flex-col items-start">
            <span className="text-[10px] text-slate-400 font-medium leading-none mb-0.5">
              Current Tenant
            </span>
            <button
              onClick={() => setShowTenantMenu(!showTenantMenu)}
              className="flex items-center gap-2 text-sm font-semibold text-slate-800 hover:text-blue-600 transition-colors py-0.5 focus:outline-none cursor-pointer"
            >
              <span>{currentTenantName}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>

          {/* Tenant Dropdown */}
          {showTenantMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-slate-200 py-1.5 z-50 text-xs">
              <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                Switch Organization
              </div>
              <div className="max-h-60 overflow-y-auto py-1">
                {tenantsList.map(t => {
                  const isSelected = t.name === currentTenantName || t.id === tenant?.id;
                  return (
                    <button
                      key={t.id || t.slug}
                      onClick={() => {
                        setTargetTenant(t.id);
                        setShowTenantMenu(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer ${
                        isSelected ? 'bg-blue-50/70 text-blue-700 font-medium' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Building2 className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-600' : 'text-slate-400'}`} />
                        <div>
                          <div className="font-medium">{t.name}</div>
                          <div className="text-[10px] text-slate-400">{t.domain || `${t.slug}.flowforge.com`}</div>
                        </div>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                    </button>
                  );
                })}
              </div>
              <div className="border-t border-slate-100 pt-1 px-1">
                <button
                  onClick={() => {
                    onNavigateTab?.('tenants');
                    setShowTenantMenu(false);
                  }}
                  className="w-full text-left px-2 py-1.5 rounded text-blue-600 hover:bg-blue-50 font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <span>Manage All Tenants</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Search input matching screenshots */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-4 h-4 text-slate-400" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Search workflows, executions..."
            className="w-56 md:w-64 pl-9 pr-3 py-1.5 bg-slate-50 hover:bg-white focus:bg-white text-xs text-slate-700 placeholder-slate-400 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
          />
        </div>

        {/* Notification bell with red badge '3' matching screenshots */}
        <div className="relative" ref={notifMenuRef}>
          <button
            onClick={() => setShowNotificationMenu(!showNotificationMenu)}
            className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center shadow-xs">
              3
            </span>
          </button>

          {/* Quick Notifications Popover */}
          {showNotificationMenu && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 text-xs">
              <div className="px-3 pb-2 border-b border-slate-100 flex items-center justify-between">
                <span className="font-semibold text-slate-800">System Notifications</span>
                <span className="text-[10px] text-blue-600 hover:underline cursor-pointer" onClick={() => { onNavigateTab?.('alerts'); setShowNotificationMenu(false); }}>
                  View All Alerts
                </span>
              </div>
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                <div className="p-3 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-1.5 text-amber-600 font-semibold mb-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                    <span>Database Latency Spike</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-snug">Check Inventory service database query latency peaked at 480ms.</p>
                  <span className="text-[10px] text-slate-400 mt-1 block">14m ago</span>
                </div>
                <div className="p-3 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-1.5 text-red-600 font-semibold mb-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                    <span>Payment Gateway Timeout</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-snug">Execution EX-1003 encountered 502 Bad Gateway. Auto-retry scheduled.</p>
                  <span className="text-[10px] text-slate-400 mt-1 block">35m ago</span>
                </div>
                <div className="p-3 hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-1.5 text-blue-600 font-semibold mb-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                    <span>Worker Node-03 Scaled</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-snug">Memory reached 78%. High-throughput replica added.</p>
                  <span className="text-[10px] text-slate-400 mt-1 block">1h ago</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Avatar Circle 'YK' matching screenshots */}
        <div className="relative" ref={userMenuRef}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="w-8 h-8 rounded-full bg-[#818cf8] text-white font-semibold text-xs flex items-center justify-center hover:opacity-90 transition-opacity cursor-pointer shadow-xs"
            title={`${user?.name || 'User'} (${user?.role || 'Tenant Admin'})`}
          >
            YK
          </button>

          {/* User & Role Switcher Popover */}
          {showUserMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 text-xs">
              <div className="p-2 border-b border-slate-100 mb-1">
                <div className="font-semibold text-slate-800">{user?.name || 'Tejas (Tenant Admin)'}</div>
                <div className="text-[11px] text-slate-500">{user?.email || 'tejas@acme.com'}</div>
                <div className="mt-1 flex items-center gap-1.5">
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 font-semibold">
                    {user?.role || 'TENANT_ADMIN'}
                  </span>
                  <span className="text-[10px] text-slate-400">· {tenant?.name || 'Acme Corp'}</span>
                </div>
              </div>

              <div className="px-2 py-1 text-[10px] font-semibold uppercase text-slate-400">
                Switch Tenant Admin Persona
              </div>
              <div className="space-y-0.5">
                {DEMO_PERSONAS.map(p => (
                  <button
                    key={p.key}
                    onClick={() => {
                      switchPersona(p.key);
                      setShowUserMenu(false);
                    }}
                    className={`w-full text-left px-2 py-1.5 rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                      user?.email === p.email ? 'bg-blue-50 text-blue-700 font-medium' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{p.label}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{p.org.split(' ')[0]}</span>
                  </button>
                ))}
              </div>

              <div className="border-t border-slate-100 pt-1 mt-1 space-y-0.5">
                <button
                  onClick={() => {
                    onNavigateTab?.('settings');
                    setShowUserMenu(false);
                  }}
                  className="w-full text-left px-2 py-1.5 rounded-lg text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer"
                >
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>Account & Settings</span>
                </button>
                <button
                  onClick={() => {
                    onNavigateTab?.('auth');
                    setShowUserMenu(false);
                  }}
                  className="w-full text-left px-2 py-1.5 rounded-lg text-blue-600 hover:bg-blue-50 flex items-center gap-2 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register Workspace</span>
                </button>
                <button
                  onClick={() => {
                    logout();
                    setShowUserMenu(false);
                  }}
                  className="w-full text-left px-2 py-1.5 rounded-lg text-red-600 hover:bg-red-50 flex items-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
