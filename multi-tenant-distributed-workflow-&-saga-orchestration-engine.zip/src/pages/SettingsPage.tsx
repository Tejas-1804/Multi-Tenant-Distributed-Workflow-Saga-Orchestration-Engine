import React, { useState, useEffect } from 'react';
import {
  User,
  Building2,
  KeyRound,
  Shield,
  Bell,
  Sliders,
  Check,
  Copy,
  Plus,
} from 'lucide-react';
import api from '../services/api.ts';
import { useAuth } from '../context/AuthContext.tsx';

export const SettingsPage: React.FC = () => {
  const { user, tenant } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'workspace' | 'api-keys' | 'notifications'>('profile');
  const [apiKeys, setApiKeys] = useState<any[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const fetchApiKeys = async () => {
    try {
      const res = await api.get('/api-keys');
      setApiKeys(res.data);
    } catch {
      setApiKeys([
        { id: 'key-1', name: 'Production Gateway Key', keyPrefix: 'wk_live_acme...', createdAt: new Date().toISOString() },
      ]);
    }
  };

  useEffect(() => {
    if (activeSubTab === 'api-keys') {
      fetchApiKeys();
    }
  }, [activeSubTab]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCreateApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) return;

    try {
      const res = await api.post('/api-keys', { name: newKeyName });
      setGeneratedKey(res.data.rawKey);
      setNewKeyName('');
      fetchApiKeys();
    } catch (err: any) {
      alert(err.response?.data?.error || err.message);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1400px] mx-auto bg-[#f8fafc] min-h-[calc(100vh-4rem)]">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-20 right-8 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-lg text-xs font-medium flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Settings & Workspace</h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Manage your account profile, workspace security, API credentials, and notification thresholds.
        </p>
      </div>

      {/* Subtabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-sm font-medium">
        {[
          { id: 'profile', label: 'User Profile', icon: User },
          { id: 'workspace', label: 'Workspace Details', icon: Building2 },
          { id: 'api-keys', label: 'API Keys', icon: KeyRound },
          { id: 'notifications', label: 'Alert Preferences', icon: Bell },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition-colors cursor-pointer text-xs font-semibold ${
                isActive
                  ? 'bg-white text-blue-700 shadow-2xs border border-slate-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Profile Tab */}
      {activeSubTab === 'profile' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs max-w-2xl space-y-5">
          <h2 className="text-base font-bold text-slate-900">User Profile</h2>

          <div className="flex items-center gap-4 pb-4 border-b border-slate-100">
            <div className="w-14 h-14 rounded-full bg-[#818cf8] text-white font-bold text-lg flex items-center justify-center shadow-xs">
              YK
            </div>
            <div>
              <div className="text-base font-bold text-slate-900">{user?.name || 'Tejas'}</div>
              <div className="text-xs text-slate-500">{user?.email || 'tejas@acme.com'}</div>
              <div className="mt-1">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold">
                  {user?.role || 'TENANT_ADMIN'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Full Name</label>
              <input
                type="text"
                readOnly
                value={user?.name || 'Tejas (Tenant Admin)'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
              <input
                type="email"
                readOnly
                value={user?.email || 'tejas@acme.com'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Assigned Tenant Admin Organization</label>
              <input
                type="text"
                readOnly
                value={tenant?.name || 'Acme Corp'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
              />
            </div>
          </div>
        </div>
      )}

      {/* Workspace Tab */}
      {activeSubTab === 'workspace' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs max-w-2xl space-y-5">
          <h2 className="text-base font-bold text-slate-900">Current Workspace Details</h2>

          <div className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Organization Name</label>
              <input
                type="text"
                readOnly
                value={tenant?.name || 'Acme Corp'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-semibold"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Custom Domain</label>
              <input
                type="text"
                readOnly
                value={tenant?.domain || 'acme.flowforge.com'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Subscription Plan</label>
              <input
                type="text"
                readOnly
                value={tenant?.plan || 'ENTERPRISE'}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-mono font-semibold"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Execution Rate Limit</label>
              <input
                type="text"
                readOnly
                value={`${tenant?.rateLimitPerMinute || 2000} requests per minute`}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* API Keys Tab */}
      {activeSubTab === 'api-keys' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-6">
          <div>
            <h2 className="text-base font-bold text-slate-900">Programmatic API Keys</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Authenticate automated webhook triggers, CLI deployments, and external microservices.
            </p>
          </div>

          {generatedKey && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 animate-in fade-in">
              <div className="text-xs font-bold text-emerald-800">New Secret Key Generated:</div>
              <div className="flex items-center justify-between bg-white border border-emerald-300 rounded-lg px-3 py-2 text-xs font-mono text-emerald-900">
                <span>{generatedKey}</span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedKey);
                    showToast('Copied API key to clipboard.');
                  }}
                  className="p-1 hover:bg-emerald-100 rounded text-emerald-700 cursor-pointer"
                  title="Copy Key"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px] text-emerald-700">Save this key now. It will not be shown again.</p>
            </div>
          )}

          <form onSubmit={handleCreateApiKey} className="flex gap-3 max-w-md">
            <input
              type="text"
              required
              value={newKeyName}
              onChange={e => setNewKeyName(e.target.value)}
              placeholder="Key label e.g. Production Ingestion"
              className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
            />
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#2563eb] hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Key</span>
            </button>
          </form>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-100 text-slate-400 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-4">Name</th>
                  <th className="py-2.5 px-4">Prefix</th>
                  <th className="py-2.5 px-4">Created At</th>
                  <th className="py-2.5 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {apiKeys.map(k => (
                  <tr key={k.id}>
                    <td className="py-3 px-4 font-semibold text-slate-800">{k.name}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{k.keyPrefix}</td>
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                      {new Date(k.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Notifications Tab */}
      {activeSubTab === 'notifications' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs max-w-2xl space-y-5">
          <h2 className="text-base font-bold text-slate-900">Alert Notification Preferences</h2>

          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200">
              <div>
                <div className="font-semibold text-slate-800">Critical Execution Failure Alert</div>
                <div className="text-[11px] text-slate-500">Dispatch webhook & email when workflow reaches Dead Letter Queue</div>
              </div>
              <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded cursor-pointer" />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200">
              <div>
                <div className="font-semibold text-slate-800">Latency Threshold Alert</div>
                <div className="text-[11px] text-slate-500">Notify operations team if p99 database query exceeds 500ms</div>
              </div>
              <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded cursor-pointer" />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200">
              <div>
                <div className="font-semibold text-slate-800">Saga Rollback Execution Log</div>
                <div className="text-[11px] text-slate-500">Record all reverse compensation transactions to security audit log</div>
              </div>
              <input type="checkbox" defaultChecked className="w-4 h-4 text-blue-600 rounded cursor-pointer" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
