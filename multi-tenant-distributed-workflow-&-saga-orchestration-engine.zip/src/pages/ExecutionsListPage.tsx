import React, { useState, useEffect } from 'react';
import {
  PlayCircle,
  Clock,
  CheckCircle2,
  XCircle,
  RotateCcw,
  RefreshCw,
  Search,
  Filter,
  ArrowRight,
} from 'lucide-react';
import api from '../services/api.ts';
import { WorkflowExecution } from '../types/index.ts';

interface ExecutionsListPageProps {
  onOpenExecution: (id: string) => void;
}

export const ExecutionsListPage: React.FC<ExecutionsListPageProps> = ({ onOpenExecution }) => {
  const [executions, setExecutions] = useState<WorkflowExecution[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  const loadExecutions = async () => {
    try {
      const res = await api.get('/executions');
      setExecutions(res.data);
    } catch (err) {
      console.error('Failed to load executions:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExecutions();
    const interval = setInterval(loadExecutions, 4000);
    return () => clearInterval(interval);
  }, []);

  const filtered = executions.filter(e => {
    const matchesStatus = filterStatus === 'ALL' || e.status === filterStatus;
    const matchesSearch =
      e.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.workflowName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto bg-[#f8fafc] min-h-[calc(100vh-4rem)]">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Executions</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Monitor real-time workflow state machines, latency, and step traces.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search executions by ID or workflow..."
            className="w-full pl-9 pr-3 py-1.5 text-xs text-slate-800 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">Status:</span>
          {['ALL', 'SUCCESS', 'RUNNING', 'FAILED'].map(status => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`px-3 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                filterStatus === status
                  ? 'bg-blue-50 text-blue-700 border border-blue-200 font-semibold'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {status === 'ALL' ? 'All' : status === 'SUCCESS' ? 'Completed' : status}
            </button>
          ))}
        </div>
      </div>

      {/* Executions Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/70 border-b border-slate-200/80 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
              <tr>
                <th className="py-3 px-6">Execution ID</th>
                <th className="py-3 px-6">Workflow</th>
                <th className="py-3 px-6">Status</th>
                <th className="py-3 px-6">Duration</th>
                <th className="py-3 px-6">Trigger</th>
                <th className="py-3 px-6">Started At</th>
                <th className="py-3 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(exec => {
                const isSuccess = exec.status === 'SUCCESS';
                const isRunning = exec.status === 'RUNNING';
                const isFailed = exec.status === 'FAILED';

                return (
                  <tr
                    key={exec.id}
                    onClick={() => onOpenExecution(exec.id)}
                    className="hover:bg-slate-50/70 transition-colors cursor-pointer"
                  >
                    <td className="py-4 px-6 font-mono font-semibold text-blue-600">
                      {exec.id}
                    </td>
                    <td className="py-4 px-6 font-semibold text-slate-900">
                      {exec.workflowName}
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                          isSuccess
                            ? 'bg-emerald-50 text-emerald-700'
                            : isRunning
                            ? 'bg-blue-50 text-blue-700'
                            : 'bg-rose-50 text-rose-700'
                        }`}
                      >
                        {isSuccess && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                        {isRunning && <Clock className="w-3 h-3 text-blue-600" />}
                        {isFailed && <XCircle className="w-3 h-3 text-rose-600" />}
                        <span>{isSuccess ? 'Completed' : isRunning ? 'Running' : 'Failed'}</span>
                      </span>
                    </td>
                    <td className="py-4 px-6 font-mono text-slate-600">
                      {exec.duration || '2.4s'}
                    </td>
                    <td className="py-4 px-6 text-slate-500 font-mono text-[11px]">
                      {exec.trigger || 'MANUAL'}
                    </td>
                    <td className="py-4 px-6 text-slate-400 font-mono text-[11px]">
                      {new Date(exec.startedAt).toLocaleTimeString()} · 22 days ago
                    </td>
                    <td className="py-4 px-6 text-right">
                      <span className="text-blue-600 font-semibold hover:underline inline-flex items-center gap-1">
                        <span>View Flow</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
