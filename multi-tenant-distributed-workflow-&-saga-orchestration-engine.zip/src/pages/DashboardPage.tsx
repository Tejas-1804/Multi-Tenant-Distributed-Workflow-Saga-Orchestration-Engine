import React, { useState, useEffect } from 'react';
import {
  Workflow,
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  Server,
  Database,
  Network,
  Users,
  Plus,
  ExternalLink,
  ChevronDown,
} from 'lucide-react';
import api from '../services/api.ts';
import { WorkflowExecution, Tenant } from '../types/index.ts';
import { useAuth } from '../context/AuthContext.tsx';

interface DashboardPageProps {
  onOpenWorkflowBuilder: (workflowId?: string) => void;
  onOpenExecutionDetail: (executionId: string) => void;
  onNavigateTab: (tab: any) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onOpenWorkflowBuilder,
  onOpenExecutionDetail,
  onNavigateTab,
}) => {
  const { tenant } = useAuth();
  const [recentExecutions, setRecentExecutions] = useState<WorkflowExecution[]>([]);
  const [tenantsList, setTenantsList] = useState<Tenant[]>([]);
  const [timeRange, setTimeRange] = useState('Last 7 Days');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [execRes, tenRes] = await Promise.all([
          api.get('/executions'),
          api.get('/tenants'),
        ]);
        if (execRes.data && execRes.data.length > 0) {
          setRecentExecutions(execRes.data.slice(0, 5));
        } else {
          // Realistic fallback matching screenshot
          setRecentExecutions([
            { id: 'EX-1001', workflowId: 'wf-1', workflowName: 'Order Processing', tenantId: 't-1', status: 'SUCCESS', startedAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(), duration: '2.4s', contextData: {}, nodeExecutions: {}, compensationsExecuted: [] },
            { id: 'EX-1002', workflowId: 'wf-2', workflowName: 'Payment Processing', tenantId: 't-1', status: 'RUNNING', startedAt: new Date(Date.now() - 1000 * 60 * 2).toISOString(), duration: '1.8s', contextData: {}, nodeExecutions: {}, compensationsExecuted: [] },
            { id: 'EX-1003', workflowId: 'wf-3', workflowName: 'User Registration', tenantId: 't-1', status: 'FAILED', startedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(), duration: '3.2s', contextData: {}, nodeExecutions: {}, compensationsExecuted: [] },
            { id: 'EX-1004', workflowId: 'wf-4', workflowName: 'Email Notification', tenantId: 't-1', status: 'SUCCESS', startedAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(), duration: '1.5s', contextData: {}, nodeExecutions: {}, compensationsExecuted: [] },
            { id: 'EX-1005', workflowId: 'wf-5', workflowName: 'Inventory Update', tenantId: 't-1', status: 'SUCCESS', startedAt: new Date(Date.now() - 1000 * 60 * 420).toISOString(), duration: '2.1s', contextData: {}, nodeExecutions: {}, compensationsExecuted: [] },
          ]);
        }

        if (tenRes.data && tenRes.data.length > 0) {
          setTenantsList(tenRes.data.slice(0, 5));
        } else {
          setTenantsList([
            { id: 't-1', name: 'Acme Corp', slug: 'acme-corp', domain: 'acme.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 2000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
            { id: 't-2', name: 'TechNova', slug: 'technova', domain: 'technova.flowforge.com', plan: 'PRO', rateLimitPerMinute: 1500, status: 'ACTIVE', createdAt: '', updatedAt: '' },
            { id: 't-3', name: 'Global Systems', slug: 'global-systems', domain: 'global.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 5000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
            { id: 't-4', name: 'Quantum Dynamics', slug: 'quantum-dynamics', domain: 'quantum.flowforge.com', plan: 'PRO', rateLimitPerMinute: 1000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
            { id: 't-5', name: 'Helios Cloud', slug: 'helios-cloud', domain: 'helios.flowforge.com', plan: 'ENTERPRISE', rateLimitPerMinute: 5000, status: 'ACTIVE', createdAt: '', updatedAt: '' },
          ]);
        }
      } catch (err) {
        // Fallback default dataset
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto bg-[#f8fafc] min-h-[calc(100vh-4rem)]">
      {/* Top Header matching Screenshots 1 & 4 */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Dashboard</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Overview of your workflows, executions and system health.
          </p>
        </div>
        <button
          onClick={() => onOpenWorkflowBuilder()}
          className="inline-flex items-center gap-2 px-4 py-2 bg-[#2563eb] hover:bg-blue-700 text-white text-sm font-medium rounded-lg shadow-sm transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Workflow</span>
        </button>
      </div>

      {/* 4 Summary Cards matching Screenshots 1 & 4 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Workflows */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Workflow className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Total Workflows</div>
              <div className="text-2xl font-bold text-slate-900 mt-0.5">24</div>
              <div className="text-[11px] text-slate-400 mt-0.5">vs last week</div>
            </div>
          </div>
          <div className="text-xs font-semibold text-emerald-600 self-start mt-1 flex items-center gap-0.5">
            <span>↑</span>
            <span>12%</span>
          </div>
        </div>

        {/* Card 2: Running */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center shrink-0">
              <Play className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Running</div>
              <div className="text-2xl font-bold text-slate-900 mt-0.5">6</div>
              <div className="text-[11px] text-slate-400 mt-0.5">vs last week</div>
            </div>
          </div>
          <div className="text-xs font-semibold text-emerald-600 self-start mt-1 flex items-center gap-0.5">
            <span>↑</span>
            <span>50%</span>
          </div>
        </div>

        {/* Card 3: Completed */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Completed</div>
              <div className="text-2xl font-bold text-slate-900 mt-0.5">142</div>
              <div className="text-[11px] text-slate-400 mt-0.5">vs last week</div>
            </div>
          </div>
          <div className="text-xs font-semibold text-emerald-600 self-start mt-1 flex items-center gap-0.5">
            <span>↑</span>
            <span>18%</span>
          </div>
        </div>

        {/* Card 4: Failed */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
              <XCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Failed</div>
              <div className="text-2xl font-bold text-slate-900 mt-0.5">12</div>
              <div className="text-[11px] text-slate-400 mt-0.5">vs last week</div>
            </div>
          </div>
          <div className="text-xs font-semibold text-rose-600 self-start mt-1 flex items-center gap-0.5">
            <span>↓</span>
            <span>8%</span>
          </div>
        </div>
      </div>

      {/* Middle Row: 7-Day Chart & Recent Executions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Chart: Workflow Executions (Last 7 Days) */}
        <div className="lg:col-span-8 bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Workflow Executions (Last 7 Days)</h2>
            </div>
            <div className="flex items-center gap-4">
              {/* Legends */}
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-rose-400" />
                  <span>Failed</span>
                </span>
                <span className="flex items-center gap-1.5 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-blue-500" />
                  <span>Running</span>
                </span>
                <span className="flex items-center gap-1.5 text-slate-600">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span>Successful</span>
                </span>
              </div>
              {/* Dropdown */}
              <div className="text-xs border border-slate-200 rounded-lg px-2.5 py-1 text-slate-600 font-medium flex items-center gap-1">
                <span>{timeRange}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </div>
            </div>
          </div>

          {/* SVG Area Chart matching screenshots */}
          <div className="w-full h-64 relative pt-2">
            <svg viewBox="0 0 700 220" className="w-full h-full overflow-visible">
              <defs>
                <linearGradient id="gradSuccess" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34d399" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#34d399" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="gradRunning" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#60a5fa" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#60a5fa" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="gradFailed" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f87171" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#f87171" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Y Axis Grid lines */}
              <g stroke="#e2e8f0" strokeDasharray="4 4" strokeWidth="1">
                <line x1="40" y1="20" x2="700" y2="20" />
                <line x1="40" y1="65" x2="700" y2="65" />
                <line x1="40" y1="110" x2="700" y2="110" />
                <line x1="40" y1="155" x2="700" y2="155" />
                <line x1="40" y1="200" x2="700" y2="200" />
              </g>

              {/* Y Axis Labels */}
              <g fill="#94a3b8" fontSize="11" textAnchor="end" fontFamily="inherit">
                <text x="30" y="24">100</text>
                <text x="30" y="69">75</text>
                <text x="30" y="114">50</text>
                <text x="30" y="159">25</text>
                <text x="30" y="204">0</text>
              </g>

              {/* Successful Curve (Green) */}
              <path
                d="M 40 160 C 120 145, 180 155, 250 165 C 320 140, 380 130, 450 145 C 520 100, 600 115, 700 135 L 700 200 L 40 200 Z"
                fill="url(#gradSuccess)"
              />
              <path
                d="M 40 160 C 120 145, 180 155, 250 165 C 320 140, 380 130, 450 145 C 520 100, 600 115, 700 135"
                fill="none"
                stroke="#10b981"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Running Curve (Blue) */}
              <path
                d="M 40 175 C 130 170, 200 178, 270 175 C 340 165, 410 170, 480 175 C 550 155, 620 155, 700 168 L 700 200 L 40 200 Z"
                fill="url(#gradRunning)"
              />
              <path
                d="M 40 175 C 130 170, 200 178, 270 175 C 340 165, 410 170, 480 175 C 550 155, 620 155, 700 168"
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Failed Curve (Red) */}
              <path
                d="M 40 188 C 120 190, 200 192, 280 188 C 350 180, 420 186, 490 190 C 560 192, 630 190, 700 194 L 700 200 L 40 200 Z"
                fill="url(#gradFailed)"
              />
              <path
                d="M 40 188 C 120 190, 200 192, 280 188 C 350 180, 420 186, 490 190 C 560 192, 630 190, 700 194"
                fill="none"
                stroke="#f87171"
                strokeWidth="1.5"
                strokeLinecap="round"
              />

              {/* X Axis Day Labels */}
              <g fill="#64748b" fontSize="11" textAnchor="middle" fontFamily="inherit">
                <text x="40" y="218">Oct 1</text>
                <text x="150" y="218">Oct 2</text>
                <text x="260" y="218">Oct 3</text>
                <text x="370" y="218">Oct 4</text>
                <text x="480" y="218">Oct 5</text>
                <text x="590" y="218">Oct 6</text>
                <text x="700" y="218">Oct 7</text>
              </g>
            </svg>
          </div>
        </div>

        {/* Right List: Recent Executions */}
        <div className="lg:col-span-4 bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Recent Executions</h2>
            <button
              onClick={() => onNavigateTab('executions')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              View All
            </button>
          </div>

          <div className="divide-y divide-slate-100 space-y-1">
            {recentExecutions.map(exec => {
              const isSuccess = exec.status === 'SUCCESS';
              const isRunning = exec.status === 'RUNNING';
              const isFailed = exec.status === 'FAILED';

              return (
                <div
                  key={exec.id}
                  onClick={() => onOpenExecutionDetail(exec.id)}
                  className="py-3 flex items-center justify-between hover:bg-slate-50/80 px-2 -mx-2 rounded-lg cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                        isSuccess
                          ? 'bg-emerald-50 text-emerald-600'
                          : isRunning
                          ? 'bg-blue-50 text-blue-600'
                          : 'bg-rose-50 text-rose-600'
                      }`}
                    >
                      {isSuccess && <CheckCircle2 className="w-4 h-4" />}
                      {isRunning && <Clock className="w-4 h-4" />}
                      {isFailed && <XCircle className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-800 leading-tight">
                        {exec.workflowName}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {exec.id}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-[11px] font-semibold px-2 py-0.5 rounded-full inline-block ${
                        isSuccess
                          ? 'bg-emerald-50 text-emerald-700'
                          : isRunning
                          ? 'bg-blue-50 text-blue-700'
                          : 'bg-rose-50 text-rose-700'
                      }`}
                    >
                      {isSuccess ? 'Completed' : isRunning ? 'Running' : 'Failed'}
                    </span>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      {exec.duration || '2.4s'} · 22 days ago
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Row: Workflows by Status, System Health, Active Tenants */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Card 1: Workflows by Status Donut */}
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs">
          <h2 className="text-base font-bold text-slate-900 mb-4">Workflows by Status</h2>
          <div className="flex items-center justify-between gap-4">
            {/* Donut graphic */}
            <div className="relative w-36 h-36 shrink-0 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {/* 50% Completed (Green) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#10b981"
                  strokeWidth="12"
                  strokeDasharray="119 238"
                  strokeDashoffset="0"
                />
                {/* 25% Running (Blue) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#3b82f6"
                  strokeWidth="12"
                  strokeDasharray="59.5 238"
                  strokeDashoffset="-119"
                />
                {/* 17% Failed (Red) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#ef4444"
                  strokeWidth="12"
                  strokeDasharray="40 238"
                  strokeDashoffset="-178.5"
                />
                {/* 8% Pending (Yellow) */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#f59e0b"
                  strokeWidth="12"
                  strokeDasharray="19 238"
                  strokeDashoffset="-218.5"
                />
              </svg>
              {/* Inner Center text */}
              <div className="absolute text-center">
                <div className="text-xl font-bold text-slate-900 leading-tight">24</div>
                <div className="text-[10px] text-slate-400 font-medium">Total</div>
              </div>
            </div>

            {/* Status Breakdown Legend */}
            <div className="space-y-2 text-xs flex-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  <span>Running</span>
                </span>
                <span className="font-semibold text-slate-800">6 (25%)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span>Completed</span>
                </span>
                <span className="font-semibold text-slate-800">12 (50%)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <span>Failed</span>
                </span>
                <span className="font-semibold text-slate-800">4 (17%)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span>Pending</span>
                </span>
                <span className="font-semibold text-slate-800">2 (8%)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 2: System Health matching screenshots */}
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">System Health</h2>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Healthy</span>
            </span>
          </div>

          <div className="space-y-3.5">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <Server className="w-4 h-4 text-slate-400" />
                <span>API Server</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-600 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Healthy
                </span>
                <span className="font-mono text-slate-400 text-[11px]">120ms</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <Database className="w-4 h-4 text-slate-400" />
                <span>Database</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-600 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Healthy
                </span>
                <span className="font-mono text-slate-400 text-[11px]">45ms</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <Network className="w-4 h-4 text-slate-400" />
                <span>Message Queue</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-600 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Healthy
                </span>
                <span className="font-mono text-slate-400 text-[11px]">32ms</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5 text-slate-700 font-medium">
                <Users className="w-4 h-4 text-slate-400" />
                <span>Workers</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-emerald-600 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Healthy
                </span>
                <span className="font-mono text-slate-400 text-[11px]">98ms</span>
              </div>
            </div>
          </div>
        </div>

        {/* Card 3: Active Tenants matching screenshots */}
        <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Active Tenants</h2>
            <button
              onClick={() => onNavigateTab('tenants')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
            >
              View All
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 font-medium">
                  <th className="pb-2">Name</th>
                  <th className="pb-2">Domain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {tenantsList.map(t => (
                  <tr key={t.id || t.slug} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-2.5 font-semibold text-slate-800">{t.name}</td>
                    <td className="py-2.5 text-slate-500 font-mono text-[11px]">
                      {t.domain || `${t.slug}.flowforge.com`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
