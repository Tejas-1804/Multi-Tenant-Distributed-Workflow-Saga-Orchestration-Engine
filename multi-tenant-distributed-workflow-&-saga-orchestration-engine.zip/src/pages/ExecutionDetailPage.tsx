import React, { useState, useEffect } from 'react';
import {
  Zap,
  FileCheck2,
  Database,
  CreditCard,
  Mail,
  RefreshCw,
  Square,
  ExternalLink,
  Minus,
  Plus,
  Maximize2,
  Box,
  AlertCircle,
  Clock,
  CheckCircle2,
  ArrowRight,
  ChevronDown,
  Layers,
} from 'lucide-react';
import api from '../services/api.ts';
import { WorkflowExecution, Workflow as IWorkflow } from '../types/index.ts';

interface ExecutionDetailPageProps {
  executionId: string;
  onBack: () => void;
  onOpenWorkflow: (workflowId: string) => void;
}

export const ExecutionDetailPage: React.FC<ExecutionDetailPageProps> = ({
  executionId,
  onBack,
  onOpenWorkflow,
}) => {
  const [activeTab, setActiveTab] = useState<'flow' | 'timeline'>('flow');
  const [zoomLevel, setZoomLevel] = useState(100);
  const [selectedNodeKey, setSelectedNodeKey] = useState<string>('inventory');
  const [execution, setExecution] = useState<WorkflowExecution | null>(null);
  const [workflow, setWorkflow] = useState<IWorkflow | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Load execution details
  const fetchExecution = async () => {
    try {
      const res = await api.get(`/executions/${executionId}`);
      setExecution(res.data);
      if (res.data.workflowId) {
        const wfRes = await api.get(`/workflows/${res.data.workflowId}`);
        setWorkflow(wfRes.data);
      }
    } catch (err) {
      // Fallback local demo state if disconnected
      setExecution({
        id: executionId || 'EX-1002',
        workflowId: 'wf-order-processing',
        workflowName: 'Order Processing',
        tenantId: 'tenant-1',
        status: 'RUNNING',
        startedAt: new Date(Date.now() - 1200).toISOString(),
        currentNodeId: 'node-inventory',
        contextData: {
          productId: 'PRD-1024',
          quantity: 25,
          warehouse: 'WH-01',
        },
        nodeExecutions: {},
        compensationsExecuted: [],
        trigger: 'WEBHOOK',
        triggeredBy: 'api_gateway',
        duration: '1.2s (in progress)',
      });
    }
  };

  useEffect(() => {
    fetchExecution();
    const interval = setInterval(fetchExecution, 5000);
    return () => clearInterval(interval);
  }, [executionId]);

  // Actions
  const handleRetry = async () => {
    setActionLoading(true);
    setActionMessage(null);
    try {
      await api.post(`/executions/${executionId}/retry`);
      setActionMessage('Execution retry queued successfully.');
      fetchExecution();
    } catch (err: any) {
      setActionMessage('Retried execution step simulated.');
    } finally {
      setActionLoading(false);
      setTimeout(() => setActionMessage(null), 3500);
    }
  };

  const handleCancel = async () => {
    setActionLoading(true);
    setActionMessage(null);
    try {
      await api.post(`/executions/${executionId}/cancel`);
      setActionMessage('Execution cancelled.');
      fetchExecution();
    } catch (err: any) {
      setActionMessage('Execution marked as cancelled.');
    } finally {
      setActionLoading(false);
      setTimeout(() => setActionMessage(null), 3500);
    }
  };

  // Node details dictionary matching screenshots
  const nodeDetailsMap: Record<
    string,
    {
      title: string;
      status: 'Completed' | 'Running' | 'Pending';
      service: string;
      description: string;
      startTime: string;
      duration: string;
      serviceType: string;
      inputData: any;
      outputData: any;
    }
  > = {
    trigger: {
      title: 'Trigger',
      status: 'Completed',
      service: 'Webhook Event Listener',
      description: 'Receives and validates incoming customer checkout event payload.',
      startTime: '07:44:27 pm',
      duration: '234ms',
      serviceType: 'Inbound Gateway / HTTP Webhook',
      inputData: {
        orderId: 'ORD-98421',
        channel: 'web_storefront',
        customerId: 'CUST-8819',
        currency: 'USD',
      },
      outputData: {
        received: true,
        traceId: 'TRC-77491-X',
      },
    },
    validate: {
      title: 'Validate Order',
      status: 'Completed',
      service: 'Order Validation Engine',
      description: 'Validates line item schema, tax exemption rules, and customer authorization.',
      startTime: '07:44:28 pm',
      duration: '512ms',
      serviceType: 'Internal Business Logic / Schema Validator',
      inputData: {
        orderId: 'ORD-98421',
        items: [{ sku: 'PRD-1024', qty: 25 }],
        fraudScore: 0.02,
      },
      outputData: {
        isValid: true,
        passedRules: ['SCHEMA_CHECK', 'FRAUD_LOW_RISK', 'TAX_CALCULATED'],
      },
    },
    inventory: {
      title: 'Check Inventory',
      status: 'Running',
      service: 'Inventory service',
      description: 'Query stock levels from inventory services.',
      startTime: '07:44:29 pm',
      duration: '1.2s (in progress)',
      serviceType: 'Inventory Services / Database Query',
      inputData: {
        productId: 'PRD-1024',
        quantity: 25,
        warehouse: 'WH-01',
      },
      outputData: null,
    },
    payment: {
      title: 'Process Payment',
      status: 'Pending',
      service: 'Payment Gateway',
      description: 'Authorize and capture funds via primary payment processor.',
      startTime: '-',
      duration: '-',
      serviceType: 'External API / Stripe Gateway',
      inputData: {
        amount: 249.99,
        currency: 'USD',
        captureMethod: 'AUTOMATIC',
      },
      outputData: null,
    },
    updateInventory: {
      title: 'Update Inventory',
      status: 'Pending',
      service: 'ERP Warehouse Stock',
      description: 'Decrement confirmed units from physical warehouse bins.',
      startTime: '-',
      duration: '-',
      serviceType: 'Warehouse Management API / SAP RFC',
      inputData: {
        sku: 'PRD-1024',
        decrementCount: 25,
      },
      outputData: null,
    },
    notify: {
      title: 'Send Notification',
      status: 'Pending',
      service: 'Customer Communications Service',
      description: 'Send alert notification if items are on backorder or stock is unavailable.',
      startTime: '-',
      duration: '-',
      serviceType: 'Messaging / Twilio SendGrid',
      inputData: {
        recipient: 'customer@example.com',
        channel: 'EMAIL_AND_SMS',
      },
      outputData: null,
    },
  };

  const selectedNode = nodeDetailsMap[selectedNodeKey] || nodeDetailsMap.inventory;

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1700px] mx-auto bg-[#f8fafc] min-h-[calc(100vh-4rem)]">
      {/* Toast Feedback */}
      {actionMessage && (
        <div className="fixed top-20 right-8 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-lg text-xs font-medium flex items-center gap-2 border border-slate-700 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Main Grid: Left Flow / Right Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Section: Execution Flow Card (col-span-7) */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/80 shadow-xs flex flex-col overflow-hidden">
          {/* Header Controls matching Screenshot 2 & 3 */}
          <div className="px-6 py-4 border-b border-slate-200/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white">
            <div className="flex items-center gap-6">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Execution Flow
              </h2>
              {/* Flow View & Execution Timeline Subtabs */}
              <div className="flex items-center gap-4 text-sm font-medium">
                <button
                  onClick={() => setActiveTab('flow')}
                  className={`pb-0.5 border-b-2 transition-all cursor-pointer ${
                    activeTab === 'flow'
                      ? 'border-[#2563eb] text-[#2563eb] font-semibold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Flow View
                </button>
                <button
                  onClick={() => setActiveTab('timeline')}
                  className={`pb-0.5 border-b-2 transition-all cursor-pointer ${
                    activeTab === 'timeline'
                      ? 'border-[#2563eb] text-[#2563eb] font-semibold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Execution Timeline
                </button>
              </div>
            </div>

            {/* Zoom Controls matching screenshots */}
            <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg p-1 self-start sm:self-auto text-xs text-slate-600">
              <button
                onClick={() => setZoomLevel(prev => Math.max(60, prev - 10))}
                className="w-6 h-6 flex items-center justify-center hover:bg-white rounded transition-colors cursor-pointer"
                title="Zoom Out"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono text-[11px] font-medium text-slate-700 min-w-[45px] text-center">
                {zoomLevel}%
              </span>
              <button
                onClick={() => setZoomLevel(prev => Math.min(150, prev + 10))}
                className="w-6 h-6 flex items-center justify-center hover:bg-white rounded transition-colors cursor-pointer"
                title="Zoom In"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <div className="w-[1px] h-4 bg-slate-200 mx-0.5" />
              <button
                onClick={() => setZoomLevel(100)}
                className="w-6 h-6 flex items-center justify-center hover:bg-white rounded transition-colors cursor-pointer"
                title="Fit View"
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Canvas Area matching Screenshot 2 & 3 */}
          {activeTab === 'flow' ? (
            <div className="p-8 sm:p-12 bg-slate-50/40 min-h-[640px] flex items-center justify-center overflow-auto relative">
              <div
                className="flex flex-col items-center transition-transform duration-200 ease-out origin-center"
                style={{ transform: `scale(${zoomLevel / 100})` }}
              >
                {/* Node 1: Trigger */}
                <div
                  onClick={() => setSelectedNodeKey('trigger')}
                  className={`w-72 bg-white rounded-xl border p-4 cursor-pointer transition-all shadow-xs flex items-center justify-between ${
                    selectedNodeKey === 'trigger'
                      ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                      : 'border-emerald-300 hover:border-emerald-400'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Zap className="w-5 h-5 fill-current" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-900 leading-tight">Trigger</div>
                      <div className="text-xs text-slate-500 font-medium">New Order</div>
                    </div>
                  </div>
                  <div className="text-xs font-semibold text-emerald-600 flex items-center gap-1 font-mono">
                    <span>✓</span>
                    <span>234ms</span>
                  </div>
                </div>

                {/* Connector Arrow 1 */}
                <div className="h-10 flex flex-col items-center justify-center relative">
                  <div className="w-[2px] h-full bg-slate-300" />
                  <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[6px] border-t-slate-400 -mt-1" />
                </div>

                {/* Node 2: Validate Order */}
                <div
                  onClick={() => setSelectedNodeKey('validate')}
                  className={`w-72 bg-white rounded-xl border p-4 cursor-pointer transition-all shadow-xs flex items-center justify-between ${
                    selectedNodeKey === 'validate'
                      ? 'border-blue-500 ring-2 ring-blue-500/20'
                      : 'border-blue-200 hover:border-blue-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <FileCheck2 className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-900 leading-tight">Validate Order</div>
                      <div className="text-xs text-slate-400 font-medium">Order rules verification</div>
                    </div>
                  </div>
                  <div className="text-xs font-semibold text-emerald-600 flex items-center gap-1 font-mono">
                    <span>✓</span>
                    <span>512ms</span>
                  </div>
                </div>

                {/* Connector Arrow 2 */}
                <div className="h-10 flex flex-col items-center justify-center relative">
                  <div className="w-[2px] h-full bg-slate-300" />
                  <div className="w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent border-t-[6px] border-t-slate-400 -mt-1" />
                </div>

                {/* Node 3: Check Inventory (Active Running Node) */}
                <div
                  onClick={() => setSelectedNodeKey('inventory')}
                  className={`w-72 bg-white rounded-xl border-2 p-4 cursor-pointer transition-all shadow-md flex items-center justify-between ${
                    selectedNodeKey === 'inventory'
                      ? 'border-purple-600 ring-4 ring-purple-500/20 shadow-purple-100'
                      : 'border-purple-500 shadow-purple-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Database className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-900 leading-tight">Check Inventory</div>
                      <div className="flex items-center gap-1.5 text-xs text-purple-600 font-semibold mt-0.5">
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        <span>Running...</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs font-semibold text-purple-700 font-mono">
                    1.2s
                  </div>
                </div>

                {/* Dual Branching Section matching Screenshot 2 & 3 */}
                <div className="w-[520px] relative pt-2">
                  {/* SVG connector lines for dual branches */}
                  <svg className="w-full h-16 overflow-visible" viewBox="0 0 520 64">
                    {/* Left branch line */}
                    <path
                      d="M 260 0 L 260 18 C 260 28, 130 28, 130 38 L 130 64"
                      fill="none"
                      stroke="#cbd5e1"
                      strokeWidth="2"
                    />
                    {/* Right branch line */}
                    <path
                      d="M 260 0 L 260 18 C 260 28, 390 28, 390 38 L 390 64"
                      fill="none"
                      stroke="#cbd5e1"
                      strokeWidth="2"
                    />
                  </svg>

                  {/* Branch Pill Badges */}
                  <div className="absolute top-5 left-[75px] -translate-x-1/2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/80 shadow-xs">
                      <Box className="w-3.5 h-3.5 text-emerald-600" />
                      <span>In Stock</span>
                    </span>
                  </div>

                  <div className="absolute top-5 left-[345px] -translate-x-1/2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200/80 shadow-xs">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                      <span>Out of Stock</span>
                    </span>
                  </div>

                  {/* Dual Destination Nodes */}
                  <div className="flex justify-between items-start pt-2">
                    {/* Node 4A: Process Payment */}
                    <div
                      onClick={() => setSelectedNodeKey('payment')}
                      className={`w-60 bg-white rounded-xl border p-4 cursor-pointer transition-all shadow-xs flex items-center justify-between ${
                        selectedNodeKey === 'payment'
                          ? 'border-blue-500 ring-2 ring-blue-500/20'
                          : 'border-blue-300 hover:border-blue-400'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                          <CreditCard className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 leading-tight">Process Payment</div>
                          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium mt-0.5">
                            <Clock className="w-3 h-3" />
                            <span>Pending</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Node 4B: Send Notification */}
                    <div
                      onClick={() => setSelectedNodeKey('notify')}
                      className={`w-60 bg-white rounded-xl border p-4 cursor-pointer transition-all shadow-xs flex items-center justify-between ${
                        selectedNodeKey === 'notify'
                          ? 'border-amber-500 ring-2 ring-amber-500/20'
                          : 'border-amber-300 hover:border-amber-400'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-amber-500 text-white flex items-center justify-center shrink-0">
                          <Mail className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-slate-900 leading-tight">Send Notification</div>
                          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium mt-0.5">
                            <Clock className="w-3 h-3" />
                            <span>Pending</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Execution Timeline View */
            <div className="p-6 divide-y divide-slate-100 max-h-[640px] overflow-y-auto">
              <div className="py-3 flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">Trigger: New Order</span>
                    <span className="text-xs text-slate-400 font-mono">07:44:27 pm</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">Cart checkout payload ingested and validated by Inbound API gateway.</p>
                  <span className="text-[11px] text-emerald-600 font-mono">Duration: 234ms</span>
                </div>
              </div>

              <div className="py-3 flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">Validate Order</span>
                    <span className="text-xs text-slate-400 font-mono">07:44:28 pm</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">Schema verification passed. Fraud risk 0.02 (Low). Tax recalculated.</p>
                  <span className="text-[11px] text-emerald-600 font-mono">Duration: 512ms</span>
                </div>
              </div>

              <div className="py-3 flex items-start gap-4">
                <div className="w-8 h-8 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center shrink-0 mt-0.5">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">Check Inventory</span>
                    <span className="text-xs text-purple-600 font-mono">07:44:29 pm (Running)</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">Executing warehouse stock query on cluster WH-01 for SKU PRD-1024.</p>
                  <span className="text-[11px] text-purple-600 font-mono">Duration: 1.2s in progress</span>
                </div>
              </div>

              <div className="py-3 flex items-start gap-4 opacity-50">
                <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">Process Payment</span>
                    <span className="text-xs text-slate-400 font-mono">Queued</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">Awaiting inventory confirmation before capturing customer credit card.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Section: Details, Status, Actions (col-span-5) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Card 1: Current Step Details matching Screenshot 2 & 3 */}
          <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Current Step Details</h2>

            {/* Header with Icon, Name, and Badge */}
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center shrink-0">
                <Database className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900">{selectedNode.title}</h3>
                  <span
                    className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                      selectedNode.status === 'Completed'
                        ? 'bg-emerald-50 text-emerald-700'
                        : selectedNode.status === 'Running'
                        ? 'bg-blue-50 text-blue-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {selectedNode.status}
                  </span>
                </div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">{selectedNode.service}</div>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {selectedNode.description}
            </p>

            {/* 3 Grid Columns */}
            <div className="grid grid-cols-3 gap-3 pt-1 border-t border-slate-100">
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Start Time</div>
                <div className="text-xs font-semibold text-slate-800 mt-0.5 font-mono">{selectedNode.startTime}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Duration</div>
                <div className="text-xs font-semibold text-slate-800 mt-0.5 font-mono">{selectedNode.duration}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase font-semibold">Service Type</div>
                <div className="text-xs font-medium text-slate-800 mt-0.5 leading-snug">{selectedNode.serviceType}</div>
              </div>
            </div>

            {/* Input Data JSON Block matching Screenshot 2 & 3 */}
            <div className="space-y-1.5 pt-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700">Input Data</span>
                <div className="flex items-center gap-1 text-slate-500 text-[11px] font-mono border border-slate-200 px-2 py-0.5 rounded">
                  <span>JSON</span>
                  <ChevronDown className="w-3 h-3" />
                </div>
              </div>
              <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3 text-xs font-mono text-slate-800 overflow-x-auto shadow-2xs">
                <pre className="text-blue-700 leading-relaxed">
                  {JSON.stringify(selectedNode.inputData, null, 2)}
                </pre>
              </div>
            </div>

            {/* Output Data JSON Block matching Screenshot 2 & 3 */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-700">Output Data</span>
                <div className="flex items-center gap-1 text-slate-500 text-[11px] font-mono border border-slate-200 px-2 py-0.5 rounded">
                  <span>JSON</span>
                  <ChevronDown className="w-3 h-3" />
                </div>
              </div>
              <div className="bg-[#f8fafc] border border-slate-200 rounded-lg p-3 text-xs font-mono text-slate-400 min-h-[48px] flex items-center">
                {selectedNode.outputData ? (
                  <pre className="text-emerald-700">
                    {JSON.stringify(selectedNode.outputData, null, 2)}
                  </pre>
                ) : (
                  <span className="italic text-slate-400">Waiting for response...</span>
                )}
              </div>
            </div>
          </div>

          {/* Card 2: Execution Status Stepper matching Screenshot 2 & 3 */}
          <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Execution Status</h2>

            <div className="relative pl-6 space-y-5 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-200">
              {/* Stepper item 1: Trigger */}
              <div className="relative flex items-center justify-between text-xs">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-4 ring-white shadow-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-semibold text-slate-800">Trigger</div>
                  <div className="text-[11px] text-emerald-600">Completed</div>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">234ms</div>
              </div>

              {/* Stepper item 2: Validate Order */}
              <div className="relative flex items-center justify-between text-xs">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center ring-4 ring-white shadow-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-semibold text-slate-800">Validate Order</div>
                  <div className="text-[11px] text-emerald-600">Completed</div>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">512ms</div>
              </div>

              {/* Stepper item 3: Check Inventory (Active) */}
              <div className="relative flex items-center justify-between text-xs">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center ring-4 ring-blue-100 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-white" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Check Inventory</div>
                  <div className="text-[11px] text-blue-600 font-medium">Running</div>
                </div>
                <div className="text-blue-600 font-mono text-[11px]">1.2s</div>
              </div>

              {/* Stepper item 4: Process Payment */}
              <div className="relative flex items-center justify-between text-xs opacity-60">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center ring-4 ring-white">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                </div>
                <div>
                  <div className="font-medium text-slate-700">Process Payment</div>
                  <div className="text-[11px] text-slate-400">Pending</div>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">-</div>
              </div>

              {/* Stepper item 5: Update Inventory */}
              <div className="relative flex items-center justify-between text-xs opacity-60">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center ring-4 ring-white">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                </div>
                <div>
                  <div className="font-medium text-slate-700">Update Inventory</div>
                  <div className="text-[11px] text-slate-400">Pending</div>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">-</div>
              </div>

              {/* Stepper item 6: Send Notification */}
              <div className="relative flex items-center justify-between text-xs opacity-60">
                <div className="absolute -left-[19px] w-5 h-5 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center ring-4 ring-white">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                </div>
                <div>
                  <div className="font-medium text-slate-700">Send Notification</div>
                  <div className="text-[11px] text-slate-400">Pending</div>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">-</div>
              </div>
            </div>
          </div>

          {/* Card 3: Execution Actions matching Screenshot 2 & 3 */}
          <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-3">
            <h2 className="text-base font-bold text-slate-900">Execution Actions</h2>

            {/* Action 1: Retry from Current Step */}
            <button
              onClick={handleRetry}
              disabled={actionLoading}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-blue-600 font-medium text-xs rounded-lg border border-blue-200 flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-2xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${actionLoading ? 'animate-spin' : ''}`} />
              <span>Retry from Current Step</span>
            </button>

            {/* Action 2: Cancel Execution */}
            <button
              onClick={handleCancel}
              disabled={actionLoading}
              className="w-full py-2.5 px-4 bg-red-50 hover:bg-red-100 text-red-600 font-medium text-xs rounded-lg border border-red-200 flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-2xs"
            >
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Cancel Execution</span>
            </button>

            {/* Action 3: View in Workflow */}
            <button
              onClick={() => onOpenWorkflow(execution?.workflowId || 'wf-order-processing')}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-700 font-medium text-xs rounded-lg border border-slate-200 flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-2xs"
            >
              <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              <span>View in Workflow</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
